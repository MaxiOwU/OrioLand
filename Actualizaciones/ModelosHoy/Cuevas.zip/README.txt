##############################################
#                                            #
#       Thank you for purchasing!            #
#                                            #
##############################################


#####!Terms of Usage:


!Do not attempt to redistribute, resell, or otherwise claim ownership of the assets provided.
!Under no circumstances are you permitted to alter assets and then redistribute for purchase, however for personal use on your servers you may make adjustments to fit your needs. 
!Credit to Mythic Studios and @cazfps1 needs to be displayed in written form when creating content for a viewership. (ie. youtube video descriptions)
!Mythic Studios creations are protected under International Copyright and Intellectual Property Law and misuse will be handled as a breach of terms.




~~Installation:
	~Mythicmobs:
		Drop the plugins/mythicmobs/packs/MythicCaveExpansion1 folder inside of YOUR packs folder on your server.
		/mm reload 
	~ModelEngine:
		Follow traditional modelengine steps, dropping .bbmodel files inside blueprints, /meg reload on your server, and pulling it's generated resourcepack to combine with your server's resourcepack.
		#OR#
		Just to install this pack standalone, drag and drop the files into ModelEngine and /meg reload!

Please make sure you have the most recent available versions of both Model Engine and Mythic Mobs. 

Models were created by @cazfps1 on twitter, skilled by Mythic Studios.		



